#!/usr/bin/env python3
"""
Generate a git repository with random directories, files, commits, branches,
varying branching depths, orphan branches, and tags.
"""

import os
import random
import string
import subprocess
import sys
from pathlib import Path

# ==============================================================================
# CONFIGURATION CONSTANTS
# ==============================================================================
RANDOM_SEED = None             # Set an integer (e.g. 42) for reproducible output
TOTAL_BRANCHES = 14            # Number of branches to create (excluding root)
MAX_BRANCH_DEPTH = 4           # Maximum branching depth / level
MIN_COMMITS_PER_BRANCH = 1     # Min commits created per branch
MAX_COMMITS_PER_BRANCH = 5     # Max commits created per branch

ORPHAN_BRANCH_CHANCE = 0.15    # Probability of creating a root/orphan branch (not based on others)
FROM_EXISTING_BRANCH_CHANCE = 0.70  # If not orphan, chance to branch off an existing branch (vs root)

MAX_DIR_DEPTH = 3              # Maximum directory nesting depth for random files
DIRS_PER_COMMIT_MAX = 2        # Max number of new directory paths per commit
FILES_PER_COMMIT_MIN = 1       # Min files created/modified per commit
FILES_PER_COMMIT_MAX = 4       # Max files created/modified per commit
MODIFY_FILE_CHANCE = 0.55      # Chance to modify an existing file instead of creating new
DELETE_FILE_CHANCE = 0.10      # When modifying, chance to delete an existing file

TAG_COUNT = 8                  # Number of random tags to create
ANNOTATED_TAG_RATIO = 0.5      # Fraction of tags that should be annotated (vs lightweight)

NUM_SYMBOLIC_REFS = 4          # Number of symbolic refs (containing 'ref: <target_ref>')
CHAINED_SYMBOLIC_REFS = True   # Create chained symbolic refs (sym_2 -> sym_1 -> target)
NUM_DUPLICATE_REFS = 3         # Direct duplicate refs (pointing to same commit as another branch)

GIT_AUTHOR_NAME = "Repo Generator"
GIT_AUTHOR_EMAIL = "generator@local.test"
# ==============================================================================


def run_git(args, cwd):
    """Run a git command in the specified directory."""
    result = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=True
    )
    return result.stdout.strip()


def random_string(length=8):
    """Generate a random alphanumeric string."""
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))


def random_file_content():
    """Generate random multiline content for files."""
    lines = [f"Random line {i}: {random_string(32)}" for i in range(random.randint(3, 15))]
    return "\n".join(lines) + "\n"


def get_tracked_files(repo_path):
    """Return relative paths of currently tracked files (excluding generator script)."""
    try:
        output = run_git(["ls-files"], repo_path)
        files = [line.strip() for line in output.splitlines() if line.strip()]
        return [f for f in files if f != "generate_repo.py"]
    except Exception:
        return []


def modify_existing_file(file_path):
    """Make random realistic edits to an existing text file."""
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        content = ""
    lines = content.splitlines()

    change_mode = random.choice(["append", "edit_line", "insert_line", "truncate"])

    if change_mode == "append" or not lines:
        lines.append(f"Appended: {random_string(24)} (edit #{random.randint(100, 999)})")
    elif change_mode == "edit_line":
        idx = random.randint(0, len(lines) - 1)
        lines[idx] = f"Updated line {idx}: {random_string(32)}"
    elif change_mode == "insert_line":
        idx = random.randint(0, len(lines))
        lines.insert(idx, f"Inserted line: {random_string(28)}")
    elif change_mode == "truncate" and len(lines) > 3:
        keep = random.randint(1, len(lines) - 1)
        lines = lines[:keep]

    file_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def apply_random_changes(repo_path):
    """Create new files, modify existing files, or delete files randomly."""
    actions = []
    file_count = random.randint(FILES_PER_COMMIT_MIN, FILES_PER_COMMIT_MAX)

    tracked = get_tracked_files(repo_path)

    for _ in range(file_count):
        should_modify = tracked and (random.random() < MODIFY_FILE_CHANCE)

        if should_modify:
            target_rel = random.choice(tracked)
            target_file = repo_path / target_rel

            if not target_file.is_file():
                continue

            if random.random() < DELETE_FILE_CHANCE and len(tracked) > 2:
                target_file.unlink(missing_ok=True)
                tracked.remove(target_rel)
                actions.append(f"delete {target_rel}")
            else:
                modify_existing_file(target_file)
                actions.append(f"modify {target_rel}")
        else:
            # Create a new file in a random directory
            depth = random.randint(0, MAX_DIR_DEPTH)
            parts = [f"dir_{random_string(5)}" for _ in range(depth)]
            target_dir = repo_path.joinpath(*parts)
            target_dir.mkdir(parents=True, exist_ok=True)

            filename = f"file_{random_string(6)}.txt"
            file_path = target_dir / filename
            file_path.write_text(random_file_content(), encoding="utf-8")

            rel_path = file_path.relative_to(repo_path).as_posix()
            tracked.append(rel_path)
            actions.append(f"create {rel_path}")

    return actions


def commit_changes(repo_path, message):
    """Stage and commit changes."""
    run_git(["add", "-A"], repo_path)
    run_git(["commit", "-m", message], repo_path)
    commit_hash = run_git(["rev-parse", "HEAD"], repo_path)
    return commit_hash


def generate_repo(target_dir=Path(".")):
    target_dir = target_dir.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    if RANDOM_SEED is not None:
        random.seed(RANDOM_SEED)

    # Initialize repository if .git doesn't exist
    if not (target_dir / ".git").is_dir():
        run_git(["init", "-b", "main"], target_dir)

    # Configure local author if needed
    try:
        run_git(["config", "user.name"], target_dir)
    except subprocess.CalledProcessError:
        run_git(["config", "user.name", GIT_AUTHOR_NAME], target_dir)

    try:
        run_git(["config", "user.email"], target_dir)
    except subprocess.CalledProcessError:
        run_git(["config", "user.email", GIT_AUTHOR_EMAIL], target_dir)

    all_commits = []
    # Track branches: dict of branch_name -> depth_level
    branches = {"main": 0}

    # Initial commits on base branch
    root_commits_count = random.randint(1, 3)
    for i in range(root_commits_count):
        actions = apply_random_changes(target_dir)
        action_summary = ", ".join(actions[:2]) if actions else "init"
        c_hash = commit_changes(target_dir, f"main: root commit {i + 1} [{action_summary}]")
        all_commits.append(c_hash)

    # Create branches with varying levels
    for b_idx in range(1, TOTAL_BRANCHES + 1):
        is_orphan = random.random() < ORPHAN_BRANCH_CHANCE
        branch_name = f"branch_{b_idx}_{random_string(4)}"

        if is_orphan:
            # Create an orphan branch not based on existing history
            run_git(["checkout", "--orphan", branch_name], target_dir)
            # Remove tracked working directory files (keep generator script) for clean orphan
            tracked_now = get_tracked_files(target_dir)
            if tracked_now:
                run_git(["rm", "-rf"] + tracked_now, target_dir)
            branches[branch_name] = 0
            branch_level = 0
            parent_info = "orphan"
        else:
            # Pick a parent branch that does not exceed MAX_BRANCH_DEPTH
            eligible_parents = [
                b for b, depth in branches.items() if depth < MAX_BRANCH_DEPTH
            ]
            if eligible_parents and random.random() < FROM_EXISTING_BRANCH_CHANCE:
                parent_branch = random.choice(eligible_parents)
                parent_level = branches[parent_branch]
            else:
                parent_branch = "main"
                parent_level = 0

            run_git(["checkout", parent_branch], target_dir)
            run_git(["checkout", "-b", branch_name], target_dir)
            branch_level = parent_level + 1
            branches[branch_name] = branch_level
            parent_info = f"based on {parent_branch} (level {branch_level})"

        # Commit random changes on this branch
        commits_in_branch = random.randint(MIN_COMMITS_PER_BRANCH, MAX_COMMITS_PER_BRANCH)
        for c_idx in range(commits_in_branch):
            actions = apply_random_changes(target_dir)
            action_summary = ", ".join(actions[:2]) if actions else "changes"
            msg = f"{branch_name}: commit {c_idx + 1}/{commits_in_branch} [{action_summary}] ({parent_info})"
            c_hash = commit_changes(target_dir, msg)
            all_commits.append(c_hash)

    # Randomly create tags
    unique_commits = list(dict.fromkeys(all_commits))
    actual_tag_count = min(TAG_COUNT, len(unique_commits))
    selected_commits = random.sample(unique_commits, actual_tag_count)

    for i, commit_hash in enumerate(selected_commits):
        tag_name = f"v{i + 1}.{random.randint(0, 9)}.{random.randint(0, 20)}"
        if random.random() < ANNOTATED_TAG_RATIO:
            # Annotated tag
            run_git(
                ["tag", "-a", tag_name, commit_hash, "-m", f"Annotated tag {tag_name}"],
                target_dir
            )
        else:
            # Lightweight tag
            run_git(["tag", tag_name, commit_hash], target_dir)

    # Randomly create duplicate refs (direct branches pointing to the same commit as another branch)
    created_duplicate_refs = []
    branch_names = list(branches.keys())
    for i in range(1, NUM_DUPLICATE_REFS + 1):
        target_branch = random.choice(branch_names)
        dup_branch_name = f"dup_{i}_{random_string(4)}"
        run_git(["branch", dup_branch_name, target_branch], target_dir)
        created_duplicate_refs.append((dup_branch_name, target_branch))

    # Randomly create symbolic refs (files containing 'ref: <target_ref>')
    created_symbolic_refs = []
    for i in range(1, NUM_SYMBOLIC_REFS + 1):
        sym_name = f"refs/heads/sym_{i}_{random_string(4)}"
        if CHAINED_SYMBOLIC_REFS and created_symbolic_refs and (i % 2 == 0):
            # Point to an existing symbolic ref to create a chain (e.g. sym_2 -> sym_1)
            target_ref = created_symbolic_refs[-1][0]
        else:
            target_ref = f"refs/heads/{random.choice(branch_names)}"
        run_git(["symbolic-ref", sym_name, target_ref], target_dir)
        created_symbolic_refs.append((sym_name, target_ref))

    # Switch back to main
    run_git(["checkout", "main"], target_dir)

    print("Repository generation complete!")
    print(f"Target directory:    {target_dir}")
    print(f"Total branches:      {len(branches)}")
    print(f"Duplicate refs:      {len(created_duplicate_refs)}")
    print(f"Symbolic refs:       {len(created_symbolic_refs)}")
    print(f"Total commits:       {len(all_commits)}")
    print(f"Total tags:          {actual_tag_count}")


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    generate_repo(target)
