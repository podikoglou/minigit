# repo-1
This fixture repository contains a single commit of a single file, thus it
should contain three (loose) objects:
- a blob
- a tree
- a commit
